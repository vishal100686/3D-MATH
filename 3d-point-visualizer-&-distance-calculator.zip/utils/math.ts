
import { Point3D } from '../types';
import * as THREE from 'three'; // Import THREE for vector operations

/**
 * Calculates the Euclidean distance between two 3D points.
 * @param p1 - The first point.
 * @param p2 - The second point.
 * @returns The distance between the two points.
 */
export const calculateDistance = (p1: Point3D, p2: Point3D): number => {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const dz = p2.z - p1.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};

/**
 * Generates a unique ID.
 * Uses crypto.randomUUID if available, otherwise a fallback.
 * @returns A unique string ID.
 */
export const generateId = (): string => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Fallback for environments where crypto.randomUUID is not available
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

/**
 * Calculates the angle in degrees between three 3D points.
 * The angle is formed at the vertex point by the vectors (vertex -> p1) and (vertex -> p2).
 * @param p1 - The first point defining one arm of the angle.
 * @param vertex - The vertex of the angle.
 * @param p2 - The second point defining the other arm of the angle.
 * @returns The angle in degrees, or NaN if points are collinear or coincident in a way that prevents angle calculation.
 */
export const calculateAngle = (p1: Point3D, vertex: Point3D, p2: Point3D): number => {
  const vec1 = new THREE.Vector3(p1.x - vertex.x, p1.y - vertex.y, p1.z - vertex.z);
  const vec2 = new THREE.Vector3(p2.x - vertex.x, p2.y - vertex.y, p2.z - vertex.z);

  const dotProduct = vec1.dot(vec2);
  const magnitudeVec1 = vec1.length();
  const magnitudeVec2 = vec2.length();

  if (magnitudeVec1 === 0 || magnitudeVec2 === 0) {
    // One or both vectors have zero length, angle is undefined or 0
    // Depending on interpretation, could return 0 or NaN. NaN is safer for "undefined".
    return NaN; 
  }

  const cosTheta = dotProduct / (magnitudeVec1 * magnitudeVec2);

  // Clamp cosTheta to the range [-1, 1] to avoid Math.acos errors due to floating point inaccuracies
  const clampedCosTheta = Math.max(-1, Math.min(1, cosTheta));
  
  const angleRadians = Math.acos(clampedCosTheta);
  return angleRadians * (180 / Math.PI); // Convert radians to degrees
};
