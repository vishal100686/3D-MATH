
import React from 'react';
import { Point3D } from '../types';
import { calculateDistance } from '../utils/math';

interface DistanceDisplayProps {
  points: Point3D[];
  selectedPointIds: string[];
}

const DistanceDisplay: React.FC<DistanceDisplayProps> = ({ points, selectedPointIds }) => {
  if (selectedPointIds.length !== 2) {
    return (
      <div className="p-4 bg-white shadow-md rounded-lg text-center">
        <p className="text-gray-600">Select two points to calculate distance.</p>
      </div>
    );
  }

  const pointA = points.find(p => p.id === selectedPointIds[0]);
  const pointB = points.find(p => p.id === selectedPointIds[1]);

  if (!pointA || !pointB) {
    return (
      <div className="p-4 bg-white shadow-md rounded-lg text-center">
        <p className="text-red-500">Error: One or both selected points not found.</p>
      </div>
    );
  }

  const distance = calculateDistance(pointA, pointB);

  return (
    <div className="p-4 bg-white shadow-md rounded-lg">
      <h3 className="text-xl font-semibold mb-2 text-gray-700">Distance</h3>
      <p className="text-gray-600 text-sm">
        Between <span className="font-medium text-indigo-600">{pointA.name}</span> and <span className="font-medium text-indigo-600">{pointB.name}</span>:
      </p>
      <p className="text-2xl font-bold text-indigo-700 mt-1">
        {distance.toFixed(4)} units
      </p>
    </div>
  );
};

export default DistanceDisplay;
