
import React, { useRef, useState, useEffect, useMemo, forwardRef, useImperativeHandle, useCallback } from 'react';
import { Canvas, useThree, extend, useFrame } from '@react-three/fiber';
import { OrbitControls, Line, Text as DreiText, Grid, Billboard } from '@react-three/drei';
import * as THREE from 'three';
import { Point3D, TriangleShape } from '../types';

extend({ ArrowHelper: THREE.ArrowHelper });

declare global {
  namespace JSX {
    interface IntrinsicElements {
      arrowHelper: any; 
    }
  }
}

export interface Scene3DHandle {
  exportImage: () => void;
  resetCamera: () => void;
}

interface ScenePointProps {
  pointData: Point3D;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

const ScenePoint: React.FC<ScenePointProps> = React.memo(({ pointData, isSelected, onSelect }) => {
  const [hovered, setHovered] = useState(false);
  const pointColor = useMemo(() => {
    if (isSelected) return '#4f46e5'; 
    if (hovered) return '#818cf8'; 
    return '#f97316'; 
  }, [isSelected, hovered]);

  const coordinatesLabel = `(${pointData.x.toFixed(1)}, ${pointData.y.toFixed(1)}, ${pointData.z.toFixed(1)})`;

  return (
    <mesh
      position={[pointData.x, pointData.y, pointData.z]}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(pointData.id);
      }}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
      onPointerOut={() => setHovered(false)}
      castShadow
    >
      <sphereGeometry args={[0.1, 24, 24]} />
      <meshStandardMaterial color={pointColor} roughness={0.4} metalness={0.2} />
      <Billboard>
        <DreiText
          position={[0, 0.2, 0]} 
          fontSize={0.08}
          color="black"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.005}
          outlineColor="#f0f0f0"
        >
          {pointData.name}
        </DreiText>
        <DreiText
            position={[0, -0.18, 0]} 
            fontSize={0.07}
            color="#333333"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0.005}
            outlineColor="#f0f0f0"
        >
            {coordinatesLabel}
        </DreiText>
      </Billboard>
    </mesh>
  );
});


interface SceneTriangleProps {
  triangle: TriangleShape;
  allPoints: Point3D[];
}

const SceneTriangle: React.FC<SceneTriangleProps> = ({ triangle, allPoints }) => {
  const p1Data = allPoints.find(p => p.id === triangle.pointIds[0]);
  const p2Data = allPoints.find(p => p.id === triangle.pointIds[1]);
  const p3Data = allPoints.find(p => p.id === triangle.pointIds[2]);

  if (!p1Data || !p2Data || !p3Data) {
    return null; 
  }

  const triangleVertices = useMemo(() => [
    new THREE.Vector3(p1Data.x, p1Data.y, p1Data.z),
    new THREE.Vector3(p2Data.x, p2Data.y, p2Data.z),
    new THREE.Vector3(p3Data.x, p3Data.y, p3Data.z),
  ], [p1Data, p2Data, p3Data]);
  
  const geometry = useMemo(() => {
    const geom = new THREE.BufferGeometry();
    geom.setFromPoints(triangleVertices);
    geom.computeVertexNormals(); 
    return geom;
  }, [triangleVertices]);

  return (
    <mesh geometry={geometry} castShadow receiveShadow>
      <meshStandardMaterial 
        color="#60a5fa" 
        opacity={0.6} 
        transparent 
        side={THREE.DoubleSide} 
        roughness={0.5}
        metalness={0.1}
      />
    </mesh>
  );
};


interface SceneCoreProps {
  points: Point3D[];
  selectedPointIds: string[];
  triangles: TriangleShape[];
  isClickToAddEnabled: boolean; // New prop
  onSelectPointInScene: (id: string) => void;
  onAddPoint: (coords: { x: number; y: number; z: number }) => void;
  onSceneReadyForExport: (gl: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera) => void;
  onOrbitControlsReady: (controls: any) => void; 
}

const SceneCore: React.FC<SceneCoreProps> = (
  { points, selectedPointIds, triangles, isClickToAddEnabled, onSelectPointInScene, onAddPoint, onSceneReadyForExport, onOrbitControlsReady }
) => {
  const { gl, scene, camera } = useThree();
  const orbitControlsRef = useRef<any>(null);

  useEffect(() => {
    onSceneReadyForExport(gl, scene, camera);
  }, [gl, scene, camera, onSceneReadyForExport]);

  useEffect(() => {
    if (orbitControlsRef.current) {
      onOrbitControlsReady(orbitControlsRef.current);
    }
  }, [orbitControlsRef, onOrbitControlsReady]);


  const initialCameraPosition = useMemo(() => new THREE.Vector3(4, 3, 4), []);
  const initialCameraLookAt = useMemo(() => new THREE.Vector3(0, 0, 0), []);

  useEffect(() => {
    camera.position.copy(initialCameraPosition);
    camera.lookAt(initialCameraLookAt);
    if (orbitControlsRef.current) {
      orbitControlsRef.current.target.copy(initialCameraLookAt);
      orbitControlsRef.current.update();
    }
  }, [camera, initialCameraPosition, initialCameraLookAt]);
  

  const handlePlaneClick = (event: any) => {
    if (!isClickToAddEnabled || event.intersections.length === 0) { // Check flag
      return;
    }
    const intersection = event.intersections[0];
    const { x, z } = intersection.point;
    onAddPoint({ x: parseFloat(x.toFixed(1)), y: 0, z: parseFloat(z.toFixed(1)) });
  };
  
  const axisLength = 2.5; 
  const axisHeadLength = 0.2 * axisLength;
  const axisHeadWidth = 0.05 * axisLength;
  const labelOffset = axisLength + 0.3;

  const lineSegments = useMemo(() => {
    const segments: THREE.Vector3[][] = [];
    if (selectedPointIds.length === 2) {
      const p1 = points.find(p => p.id === selectedPointIds[0]);
      const p2 = points.find(p => p.id === selectedPointIds[1]);
      if (p1 && p2) {
        segments.push([
          new THREE.Vector3(p1.x, p1.y, p1.z),
          new THREE.Vector3(p2.x, p2.y, p2.z)
        ]);
      }
    } else if (selectedPointIds.length === 3) {
      const p0 = points.find(p => p.id === selectedPointIds[0]); 
      const p1_vertex = points.find(p => p.id === selectedPointIds[1]); 
      const p2 = points.find(p => p.id === selectedPointIds[2]); 
      
      if (p0 && p1_vertex) {
        segments.push([
          new THREE.Vector3(p0.x, p0.y, p0.z),
          new THREE.Vector3(p1_vertex.x, p1_vertex.y, p1_vertex.z)
        ]);
      }
      if (p1_vertex && p2) {
         segments.push([
          new THREE.Vector3(p1_vertex.x, p1_vertex.y, p1_vertex.z),
          new THREE.Vector3(p2.x, p2.y, p2.z)
        ]);
      }
    }
    return segments;
  }, [points, selectedPointIds]);

  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight
        position={[8, 12, 6]}
        intensity={1.8}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={30}
        shadow-camera-left={-15}
        shadow-camera-right={15}
        shadow-camera-top={15}
        shadow-camera-bottom={-15}
      />
      <Grid
        infiniteGrid
        cellSize={0.5}
        sectionSize={2.5}
        sectionColor={new THREE.Color(0x888888)} 
        cellColor={new THREE.Color(0xcccccc)}    
        cellThickness={0.5}
        sectionThickness={1}
        fadeDistance={60}
        fadeStrength={1.2}
      />

      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.05, 16, 16]} />
        <meshStandardMaterial color="yellow" emissive="yellow" emissiveIntensity={0.5} roughness={0.1} />
      </mesh>

      <arrowHelper args={[new THREE.Vector3(1, 0, 0), new THREE.Vector3(0, 0, 0), axisLength, 0xff0000, axisHeadLength, axisHeadWidth]} />
      <DreiText position={[labelOffset, 0.05, 0]} fontSize={0.15} color="red" anchorX="center" anchorY="middle" outlineWidth={0.005} outlineColor="white">X</DreiText>

      <arrowHelper args={[new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 0), axisLength, 0x00ff00, axisHeadLength, axisHeadWidth]} />
      <DreiText position={[0, labelOffset + 0.05, 0]} fontSize={0.15} color="green" anchorX="center" anchorY="middle" outlineWidth={0.005} outlineColor="white">Y</DreiText>

      <arrowHelper args={[new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, 0, 0), axisLength, 0x0000ff, axisHeadLength, axisHeadWidth]} />
      <DreiText position={[0, 0.05, labelOffset]} fontSize={0.15} color="blue" anchorX="center" anchorY="middle" outlineWidth={0.005} outlineColor="white">Z</DreiText>
      
      <OrbitControls
        ref={orbitControlsRef}
        enableDamping
        dampingFactor={0.05}
        screenSpacePanning={true} 
        minDistance={0.5}
        maxDistance={50}
      />

      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]} 
        onClick={isClickToAddEnabled ? handlePlaneClick : undefined} // Conditionally attach onClick
        visible={false} 
      >
        <planeGeometry args={[100, 100]} />
        {/* Material needs to be interactive if visible, or invisible plane for raycasting */}
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.005, 0]} receiveShadow>
        <planeGeometry args={[100, 100]} />
        <shadowMaterial opacity={0.4} />
      </mesh>

      {points.map((point) => (
        <ScenePoint
          key={point.id}
          pointData={point}
          isSelected={selectedPointIds.includes(point.id)}
          onSelect={onSelectPointInScene}
        />
      ))}
      {lineSegments.map((segment, index) => (
        <Line
          key={`line-${index}`}
          points={segment}
          color="magenta"
          lineWidth={2.5}
        />
      ))}
      {triangles.map((triangle) => (
        <SceneTriangle key={triangle.id} triangle={triangle} allPoints={points} />
      ))}
    </>
  );
};


interface Scene3DProps {
  points: Point3D[];
  selectedPointIds: string[];
  triangles: TriangleShape[];
  isClickToAddEnabled: boolean; // New prop
  onSelectPointInScene: (id: string) => void;
  onAddPoint: (coords: { x: number; y: number; z: number }) => void;
}

const Scene3D = forwardRef<Scene3DHandle, Scene3DProps>(
  (props, ref) => {
    const sceneElementsRef = useRef<{
      gl?: THREE.WebGLRenderer;
      scene?: THREE.Scene;
      camera?: THREE.Camera;
      orbitControls?: any;
    }>({});

    const initialCameraPosition = useMemo(() => new THREE.Vector3(4, 3, 4), []);
    const initialCameraLookAt = useMemo(() => new THREE.Vector3(0, 0, 0), []);

    useImperativeHandle(ref, () => ({
      exportImage: () => {
        const { gl, scene, camera } = sceneElementsRef.current;
        if (gl && scene && camera) {
          gl.render(scene, camera); 
          const dataURL = gl.domElement.toDataURL('image/png');
          const link = document.createElement('a');
          link.download = '3d_scene.png';
          link.href = dataURL;
          link.click();
        } else {
          console.error("Scene elements not ready for export.");
        }
      },
      resetCamera: () => {
        const { camera, orbitControls } = sceneElementsRef.current;
        if (camera && orbitControls) {
          camera.position.copy(initialCameraPosition);
          orbitControls.target.copy(initialCameraLookAt);
          orbitControls.update(); 
        } else {
           console.error("Camera or controls not ready for reset.");
        }
      }
    }));

    const handleSceneReady = useCallback((gl: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera) => {
      sceneElementsRef.current.gl = gl;
      sceneElementsRef.current.scene = scene;
      sceneElementsRef.current.camera = camera;
    }, []);
    
    const handleOrbitControlsReady = useCallback((controls: any) => {
        sceneElementsRef.current.orbitControls = controls;
    }, []);

    const canvasContainerClass = `w-full h-full bg-gray-300 ${props.isClickToAddEnabled ? 'cursor-crosshair' : 'cursor-grab'}`;

    return (
      <div className={canvasContainerClass}>
        <Canvas
          shadows
          dpr={[1, 2]} 
          gl={{ preserveDrawingBuffer: true, antialias: true }}
          camera={{ fov: 50, position: initialCameraPosition }}
        >
          <SceneCore 
            {...props} 
            onSceneReadyForExport={handleSceneReady}
            onOrbitControlsReady={handleOrbitControlsReady}
          />
        </Canvas>
      </div>
    );
  }
);

export default Scene3D;
