
import React from 'react';
import { Point3D } from '../types';
import { calculateAngle } from '../utils/math';

interface AngleDisplayProps {
  points: Point3D[];
  selectedPointIds: string[]; // Expects 3 IDs: [arm1, vertex, arm2]
}

const AngleDisplay: React.FC<AngleDisplayProps> = ({ points, selectedPointIds }) => {
  if (selectedPointIds.length !== 3) {
    // This component should only be rendered when 3 points are selected.
    // However, adding a safeguard.
    return (
        <div className="p-4 bg-white shadow-md rounded-lg text-center">
            <p className="text-gray-600">Select three points to calculate an angle. (Vertex is the 2nd selected).</p>
        </div>
    );
  }

  const p1 = points.find(p => p.id === selectedPointIds[0]);
  const vertex = points.find(p => p.id === selectedPointIds[1]);
  const p2 = points.find(p => p.id === selectedPointIds[2]);

  if (!p1 || !vertex || !p2) {
    return (
      <div className="p-4 bg-white shadow-md rounded-lg text-center">
        <p className="text-red-500">Error: One or more selected points for angle calculation not found.</p>
      </div>
    );
  }

  const angle = calculateAngle(p1, vertex, p2);

  return (
    <div className="p-4 bg-white shadow-md rounded-lg">
      <h3 className="text-xl font-semibold mb-2 text-gray-700">Angle</h3>
      <p className="text-gray-600 text-sm">
        Angle at <span className="font-medium text-indigo-600">{vertex.name}</span> 
        (formed by <span className="font-medium text-indigo-600">{p1.name}</span>
        &nbsp;&ndash;&nbsp;<span className="font-medium text-indigo-600">{vertex.name}</span>
        &nbsp;&ndash;&nbsp;<span className="font-medium text-indigo-600">{p2.name}</span>):
      </p>
      <p className="text-2xl font-bold text-indigo-700 mt-1">
        {isNaN(angle) ? "Undefined (collinear/coincident)" : `${angle.toFixed(2)}°`}
      </p>
    </div>
  );
};

export default AngleDisplay;
