
import React from 'react';
import { Point3D } from '../types';

interface PointListProps {
  points: Point3D[];
  selectedPointIds: string[];
  onSelectPoint: (id: string) => void;
  onEditPoint: (point: Point3D) => void;
  onDeletePoint: (id: string) => void;
}

const PointList: React.FC<PointListProps> = ({ points, selectedPointIds, onSelectPoint, onEditPoint, onDeletePoint }) => {
  if (points.length === 0) {
    return <p className="text-gray-500 text-center py-4">No points added yet.</p>;
  }

  return (
    <div className="p-4 bg-white shadow-md rounded-lg mb-6">
      <h3 className="text-xl font-semibold mb-4 text-gray-700">Points List</h3>
      <ul className="space-y-2 max-h-60 overflow-y-auto">
        {points.map((point) => (
          <li
            key={point.id}
            className={`p-3 rounded-md flex justify-between items-center transition-colors duration-150 ease-in-out cursor-pointer
              ${selectedPointIds.includes(point.id) ? 'bg-indigo-100 border-indigo-500 border-l-4' : 'bg-gray-50 hover:bg-gray-100 border border-transparent'}`}
            onClick={() => onSelectPoint(point.id)}
          >
            <div>
              <span className="font-medium text-gray-800">{point.name}</span>
              <p className="text-xs text-gray-500">
                (X: {point.x.toFixed(2)}, Y: {point.y.toFixed(2)}, Z: {point.z.toFixed(2)})
              </p>
            </div>
            <div className="space-x-2">
              <button
                onClick={(e) => { e.stopPropagation(); onEditPoint(point); }}
                className="px-2 py-1 text-xs font-medium text-blue-600 hover:text-blue-800 focus:outline-none"
                aria-label={`Edit point ${point.name}`}
              >
                Edit
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onDeletePoint(point.id); }}
                className="px-2 py-1 text-xs font-medium text-red-600 hover:text-red-800 focus:outline-none"
                aria-label={`Delete point ${point.name}`}
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PointList;
