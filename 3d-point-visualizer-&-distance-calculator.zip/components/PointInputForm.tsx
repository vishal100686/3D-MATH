
import React, { useState, useEffect } from 'react';
import { Point3D } from '../types';
import { generateId } from '../utils/math';

interface PointInputFormProps {
  onSubmitPoint: (point: Point3D) => void;
  editingPoint: Point3D | null;
  onCancelEdit: () => void;
}

const PointInputForm: React.FC<PointInputFormProps> = ({ onSubmitPoint, editingPoint, onCancelEdit }) => {
  const [name, setName] = useState('');
  const [x, setX] = useState('');
  const [y, setY] = useState('');
  const [z, setZ] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (editingPoint) {
      setName(editingPoint.name);
      setX(editingPoint.x.toString());
      setY(editingPoint.y.toString());
      setZ(editingPoint.z.toString());
      setError(null);
    } else {
      // Reset form when not editing or when editingPoint becomes null
      setName('');
      setX('');
      setY('');
      setZ('');
      setError(null);
    }
  }, [editingPoint]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const numX = parseFloat(x);
    const numY = parseFloat(y);
    const numZ = parseFloat(z);

    if (isNaN(numX) || isNaN(numY) || isNaN(numZ)) {
      setError('Coordinates X, Y, and Z must be valid numbers.');
      return;
    }
    if (name.trim() === '') {
      setError('Point name cannot be empty.');
      return;
    }

    onSubmitPoint({
      id: editingPoint ? editingPoint.id : generateId(),
      name: name.trim(),
      x: numX,
      y: numY,
      z: numZ,
    });

    if (!editingPoint) { // Only reset if adding new point
      setName('');
      setX('');
      setY('');
      setZ('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-white shadow-md rounded-lg mb-6">
      <h3 className="text-xl font-semibold mb-4 text-gray-700">
        {editingPoint ? 'Edit Point' : 'Add New Point'}
      </h3>
      {error && <p className="text-red-500 text-sm mb-3">{error}</p>}
      <div className="mb-3">
        <label htmlFor="pointName" className="block text-sm font-medium text-gray-600 mb-1">Name</label>
        <input
          id="pointName"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g., P1"
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-lime-600"
        />
      </div>
      <div className="grid grid-cols-3 gap-3 mb-3">
        <div>
          <label htmlFor="pointX" className="block text-sm font-medium text-gray-600 mb-1">X</label>
          <input
            id="pointX"
            type="number"
            step="any"
            value={x}
            onChange={(e) => setX(e.target.value)}
            placeholder="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-lime-600"
          />
        </div>
        <div>
          <label htmlFor="pointY" className="block text-sm font-medium text-gray-600 mb-1">Y</label>
          <input
            id="pointY"
            type="number"
            step="any"
            value={y}
            onChange={(e) => setY(e.target.value)}
            placeholder="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-lime-600"
          />
        </div>
        <div>
          <label htmlFor="pointZ" className="block text-sm font-medium text-gray-600 mb-1">Z</label>
          <input
            id="pointZ"
            type="number"
            step="any"
            value={z}
            onChange={(e) => setZ(e.target.value)}
            placeholder="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-lime-600"
          />
        </div>
      </div>
      <div className="flex justify-end space-x-2">
        {editingPoint && (
          <button
            type="button"
            onClick={onCancelEdit}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          {editingPoint ? 'Update Point' : 'Add Point'}
        </button>
      </div>
    </form>
  );
};

export default PointInputForm;
